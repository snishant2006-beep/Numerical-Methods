
%author: Nishant Sahoo
%date: 06.02.25
%My inputs are the lamda's of the elements, the number of years and the
%number of steps that will be taken to reach the number of years defined. 
%My outputs are the number of atoms of each element at each step
%represented as a matrix by both the Monte Carlo and analytic methods. 
%The limitations of the monte carlo method occur at steps less than 100 as
%the graph becomes very piecewise and does not converge usually.


function[all_atoms,N] = f(initial_pop,years,step,L_1,L_2,L_3,L_4)
U_vector = ones(1, initial_pop(1));
Th_vector = zeros(1);
Ra_vector = zeros(1);
Rn_vector = zeros(1);
%define initial population vectors for all the elements
for i= 1:1:step
   Uapprox_prob = ones(1, sum(U_vector))*L_1*years/step;
   Urandom_vector = rand(1, sum(U_vector));
    for j = 1:1:sum(U_vector)
        if Uapprox_prob(j)>Urandom_vector(j)
            Udecay_vector(j) = 1;
        else
            Udecay_vector(j) = 0;
        end
    end
   U_vector = U_vector - Udecay_vector;
   U_vector = ones(1,sum(U_vector));
   Th_vector = ones(1, sum(Udecay_vector)+sum(Th_vector));
   Udecay_vector = zeros(1,sum(U_vector));
%we are given the parameter that has to be exceeded in order for the atom
%to decay. Made a matrix with the same dimensions as the number of atoms to
%find a probability for all atoms after each iteration the size of the
%vectors change to accomodate losses or gains in number. Reset decay vector
%so that size can change.
   Thapprox_prob = ones(1, sum(Th_vector))*L_2*years/step;
   Thrandom_vector = rand(1, sum(Th_vector));
   if sum(Th_vector) == 0
      n = size(Th_vector);
      Thdecay_vector = zeros(1,n(2));
   else
     for k = 1:1:sum(Th_vector)
        if Thapprox_prob(k)>Thrandom_vector(k)
            Thdecay_vector(k) = 1;
        else 
            Thdecay_vector(k) = 0;
        end
     end
  Th_vector = Th_vector - Thdecay_vector;
  Th_vector = ones(1,sum(Th_vector));
  Ra_vector = ones(1, sum(Thdecay_vector)+sum(Ra_vector));
  Thdecay_vector = zeros(1,sum(Th_vector));
   end
  Raapprox_prob = ones(1, sum(Ra_vector))*(1-exp(-L_3*years/step));
  Rarandom_vector = rand(1, sum(Ra_vector));
  if sum(Ra_vector) == 0
      p = size(Ra_vector);
      Radecay_vector = zeros(1,p(2));
   else
     for k = 1:1:sum(Ra_vector)
        if Raapprox_prob(k)>Rarandom_vector(k)
            Radecay_vector(k) = 1;
        else 
            Radecay_vector(k) = 0;
        end
     end
  Ra_vector = Ra_vector - Radecay_vector;
  Ra_vector = ones(1,sum(Ra_vector));
  Rn_vector = ones(1, sum(Radecay_vector)+sum(Rn_vector));
  Radecay_vector = zeros(1,sum(Ra_vector));
  end
  Rnapprox_prob = ones(1, sum(Rn_vector))*(1-exp(-L_4*years/step));
  Rnrandom_vector = rand(1, sum(Rn_vector));
  if sum(Rn_vector) == 0
      p = size(Rn_vector);
      Rndecay_vector = zeros(1,p(2));
   else
     for k = 1:1:sum(Rn_vector)
        if Rnapprox_prob(k)>Rnrandom_vector(k)
            Rndecay_vector(k) = 1;
        else 
            Rndecay_vector(k) = 0;
        end
     end
  Rn_vector = Rn_vector - Rndecay_vector;
  Rn_vector = ones(1,sum(Rn_vector));
  Rndecay_vector = zeros(1,sum(Rn_vector));
  end
number(1,i) = sum(U_vector);
number(2,i) = sum(Th_vector);
number(3,i) = sum(Ra_vector);
number(4,i) = sum(Rn_vector);
number(5,i) = initial_pop - (sum(U_vector) + sum(Th_vector) + sum(Ra_vector) + sum(Rn_vector));
N(1,i) = initial_pop*exp(-L_1*years*i/step);
N(2,i) = initial_pop*(L_1/(L_2-L_1))*(exp(-L_1*years*i/step)-exp(-L_2*years*i/step));
N(3,i) = initial_pop*L_1*L_2*(((exp(-L_1*years*i/step))/((L_1-L_2)*(L_1-L_3))) + ((exp(-L_2*years*i/step))/((L_2-L_1)*(L_2-L_3))) + ((exp(-L_3*years*i/step))/((L_3-L_2)*(L_3-L_1))));
N(4,i) = initial_pop*L_1*L_2*L_3*(((-exp(-L_1*years*i/step))/((L_1-L_2)*(L_1-L_3)*(L_1-L_4))) + ((-exp(-L_2*years*i/step))/((L_2-L_1)*(L_2-L_3)*(L_2-L_4))) + ((-exp(-L_3*years*i/step))/((L_3-L_2)*(L_3-L_1))*(L_3-L_4)) + ((-exp(-L_4*years*i/step))/((L_4-L_2)*(L_4-L_1))*(L_4-L_3)));
N(5,i) = initial_pop - (N(1,i) + N(2,i) + N(3,i) + N(4,i));
%final populations displayed after all steps
end
all_atoms = number;
x = (years/step):(years/step):years;
figure 
xlabel('Years')
plot(x, all_atoms(1, :))
hold on
plot(x, N(1, :))
for l = 2:1:5
plot(x, all_atoms(l, :))
plot(x, N(l, :))
end
xlabel('Years')
ylabel('Number of atoms')
end

f(1000,500000,5000,2.77e-6,8.86e-6,4.28e-4,63.2)


